package com.example.examen_practico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenPracticoApplicationTests {

	@Test
	void contextLoads() {
	}

}
