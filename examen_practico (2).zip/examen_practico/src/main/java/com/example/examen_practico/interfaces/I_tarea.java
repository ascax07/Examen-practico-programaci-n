package com.example.examen_practico.interfaces;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.example.examen_practico.models.tarea;

@Repository
public interface I_tarea extends CrudRepository<tarea, String>  {

    @Query("SELECT u FROM tarea u WHERE  DATEDIFF(NOW(), u.due_date) >= 0")
    List<tarea> iniciosesionNotificar(String iniciosesionNotificar);

}

