package com.example.examen_practico.controller;



import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.examen_practico.interfaceService.I_tareaService;
import com.example.examen_practico.models.tarea;
import com.example.examen_practico.service.emailService;






@RequestMapping("/api/v1/tarea")
@RestController
@CrossOrigin
@Validated

public class tareaController {

    
    	@Autowired
	private I_tareaService tareaService;

	
    @Autowired
    private emailService emailService;
	
	@PostMapping("/tasks")
    public ResponseEntity<Object> save(@RequestBody tarea tarea) {
        tarea.setDue_date(new Date()); // Asigna la fecha de actualización actual
        tareaService.save(tarea);
        emailService.enviarCorreoBienvenida(tarea.getAssigned_to()); // Uso correcto
        return new ResponseEntity<>(tarea, HttpStatus.OK);
    }
        

	
	
	@GetMapping("/tasks")
	public ResponseEntity<Object> findAll(){
		var listaTarea=tareaService.findAll();
		return new ResponseEntity<>(listaTarea,HttpStatus.OK);
	}
	

	
	@GetMapping("/tasks{id}")
	public ResponseEntity<Object> findOne(@PathVariable("id") String id){
		var tarea=tareaService.findOne(id);
		return new ResponseEntity<>(tarea,HttpStatus.OK);
	}

	
	
	@DeleteMapping("/tasks{id}")
	public ResponseEntity<Object> delete(@PathVariable("id") String id){
		tareaService.delete(id);
		return new ResponseEntity<>("Registro Eliminado",HttpStatus.OK);
	}
	
	@PutMapping("/tasks{id}")
	public ResponseEntity<Object> update(@PathVariable("id") String id, @RequestBody tarea tareaUpdate){
		var tarea= tareaService.findOne(id).get();
		
		if (tarea != null) {
			tarea.setTitle(tareaUpdate.getTitle());
			tarea.setDue_date(tareaUpdate.getDue_date());
			tarea.setAssigned_to(tareaUpdate.getAssigned_to());
			tarea.setStatus(tareaUpdate.getStatus());
			tareaService.save(tarea);
			return new ResponseEntity<>("Guardado",HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>("Error tarea no encontrado",HttpStatus.BAD_REQUEST);
		}
		
	}

}