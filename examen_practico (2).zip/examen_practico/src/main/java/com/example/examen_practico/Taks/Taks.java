package com.example.examen_practico.Taks;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.example.examen_practico.models.tarea;
import com.example.examen_practico.service.emailService;
import com.example.examen_practico.service.tareaService;




@Component
public class Taks {

    @Autowired
    private tareaService data;

    @Autowired
    private emailService email;



    @Scheduled(fixedRate = 60000)
    public void notifyLogin() {
        var listaTarea = data.iniciosesionNotificar("");
        for (tarea tarea : listaTarea) {
            System.out.println("tarea que requiere iniciar sesión: " + tarea.getTitle());
            email.iniciosesionNotificar(tarea.getAssigned_to());
        }
    }



}