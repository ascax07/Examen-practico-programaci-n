package com.example.examen_practico.interfaceService;

import java.util.List;
import java.util.Optional;

import com.example.examen_practico.models.tarea;

public interface I_tareaService {
    
    public String save(tarea tarea);    
    public List<tarea> findAll();
    public Optional<tarea> findOne(String id);
    public int delete(String id);
    public List<tarea> iniciosesionNotificar(String iniciosesionNotificar);


}
