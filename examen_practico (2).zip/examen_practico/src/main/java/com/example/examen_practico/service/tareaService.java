package com.example.examen_practico.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.examen_practico.interfaceService.I_tareaService;
import com.example.examen_practico.interfaces.I_tarea;
import com.example.examen_practico.models.tarea;

@Service
public class tareaService implements I_tareaService{
    
    @Autowired
    private I_tarea data;




    @Override
    public List<tarea> findAll() {
        List<tarea> listaTarea = (List<tarea>) data.findAll();
        
        return listaTarea;
    }


//   @Override
//     public List<tarea> filtrotarea(String filtro) {
//         return data.filtrotarea(filtro);
//     }


    @Override
    public Optional<tarea> findOne(String id) {
        Optional<tarea> tarea = data.findById(id);
        
        return tarea;
    }

    @Override
    public int delete(String id) {
        data.deleteById(id);
        return 1;
    }

    @Override
    public String save(tarea tarea) {
        data.save(tarea);
        return tarea.getId();
    }


  
    @Override
    public List<tarea> iniciosesionNotificar(String iniciosesionNotificar) {
        List<tarea> listaTarea = data.iniciosesionNotificar(iniciosesionNotificar);
        return listaTarea;
    }


   

}
